<?php
if (!empty($_FILES['img'])) {
	// 验证略
	
	$ext = substr($_FILES['img']['name'], strrpos($_FILES['img']['name'], '.')+1);
	move_uploaded_file($_FILES['img']['tmp_name'], "uploads/{$_POST['uuid']}.{$ext}");

	echo "<script>parent.imgUploader.afterupload('{$_POST['uuid']}','{$ext}')</script>";
}
